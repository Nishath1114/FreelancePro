## Packages
recharts | For visualizing finance data (earnings/growth charts)
framer-motion | For smooth page transitions and micro-interactions
date-fns | For formatting dates in tables and cards
lucide-react | Already in base stack, but emphasized for icons

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
