import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertCertification } from "@shared/routes";
import { DEMO_USER_ID } from "./use-user";

export function useCertifications(userId: number = DEMO_USER_ID) {
  return useQuery({
    queryKey: [api.certifications.list.path, userId],
    queryFn: async () => {
      const res = await fetch(`${api.certifications.list.path}?userId=${userId}`, { 
        credentials: "include" 
      });
      if (!res.ok) throw new Error("Failed to fetch certifications");
      return api.certifications.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateCertification() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertCertification) => {
      const validated = api.certifications.create.input.parse(data);
      const res = await fetch(api.certifications.create.path, {
        method: api.certifications.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.certifications.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create certification");
      }
      return api.certifications.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.certifications.list.path] });
    },
  });
}

export function useDeleteCertification() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.certifications.delete.path, { id });
      const res = await fetch(url, { 
        method: api.certifications.delete.method, 
        credentials: "include" 
      });
      if (!res.ok) throw new Error("Failed to delete certification");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.certifications.list.path] });
    },
  });
}
