import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertFinance } from "@shared/routes";
import { DEMO_USER_ID } from "./use-user";

export function useFinances(userId: number = DEMO_USER_ID) {
  return useQuery({
    queryKey: [api.finances.list.path, userId],
    queryFn: async () => {
      const res = await fetch(`${api.finances.list.path}?userId=${userId}`, { 
        credentials: "include" 
      });
      if (!res.ok) throw new Error("Failed to fetch finances");
      return api.finances.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateFinance() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertFinance) => {
      const validated = api.finances.create.input.parse(data);
      const res = await fetch(api.finances.create.path, {
        method: api.finances.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.finances.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create finance record");
      }
      return api.finances.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.finances.list.path] });
    },
  });
}
