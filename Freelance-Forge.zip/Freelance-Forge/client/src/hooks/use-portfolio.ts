import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertPortfolioItem } from "@shared/routes";
import { DEMO_USER_ID } from "./use-user";

export function usePortfolio(userId: number = DEMO_USER_ID) {
  return useQuery({
    queryKey: [api.portfolio.list.path, userId],
    queryFn: async () => {
      const res = await fetch(`${api.portfolio.list.path}?userId=${userId}`, { 
        credentials: "include" 
      });
      if (!res.ok) throw new Error("Failed to fetch portfolio");
      return api.portfolio.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreatePortfolioItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertPortfolioItem) => {
      const validated = api.portfolio.create.input.parse(data);
      const res = await fetch(api.portfolio.create.path, {
        method: api.portfolio.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.portfolio.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create portfolio item");
      }
      return api.portfolio.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.portfolio.list.path] });
    },
  });
}

export function useDeletePortfolioItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.portfolio.delete.path, { id });
      const res = await fetch(url, { 
        method: api.portfolio.delete.method, 
        credentials: "include" 
      });
      if (!res.ok) throw new Error("Failed to delete item");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.portfolio.list.path] });
    },
  });
}
