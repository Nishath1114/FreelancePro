import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertUser } from "@shared/routes";

// For demo purposes, we'll hardcode userId to 1 since there's no auth flow in requirements
export const DEMO_USER_ID = 1;

export function useUser(id: number = DEMO_USER_ID) {
  return useQuery({
    queryKey: [api.user.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.user.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch user");
      return api.user.get.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<InsertUser>) => {
      const validated = api.user.update.input.parse(updates);
      const url = buildUrl(api.user.update.path, { id });
      const res = await fetch(url, {
        method: api.user.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 404) throw new Error("User not found");
        throw new Error("Failed to update user");
      }
      return api.user.update.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.user.get.path, data.id] });
    },
  });
}
