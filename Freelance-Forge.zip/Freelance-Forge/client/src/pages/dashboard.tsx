import { useUser } from "@/hooks/use-user";
import { useJobs } from "@/hooks/use-jobs";
import { useFinances } from "@/hooks/use-finances";
import { 
  DollarSign, 
  Briefcase, 
  CheckCircle, 
  ArrowUpRight, 
  Clock,
  User 
} from "lucide-react";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: user, isLoading: userLoading } = useUser();
  const { data: jobs, isLoading: jobsLoading } = useJobs();
  const { data: finances, isLoading: financesLoading } = useFinances();

  if (userLoading || jobsLoading || financesLoading) {
    return <DashboardSkeleton />;
  }

  const activeJobs = jobs?.filter(j => j.status === 'active') || [];
  const leads = jobs?.filter(j => j.status === 'leads') || [];
  
  const totalEarnings = finances
    ?.filter(f => f.type === 'earning')
    .reduce((acc, curr) => acc + Number(curr.amount), 0) || 0;

  const activeProposals = jobs?.filter(j => j.status === 'applied' || j.status === 'interviewing') || [];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-display font-bold text-foreground">
          Welcome back, {user?.fullName || "Freelancer"}!
        </h2>
        <p className="text-muted-foreground mt-2">Here's what's happening with your business today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Earnings" 
          value={`$${totalEarnings.toLocaleString()}`} 
          icon={DollarSign}
          trend="+12.5%" 
          trendUp={true}
          color="bg-emerald-50 text-emerald-600"
        />
        <StatCard 
          title="Active Jobs" 
          value={activeJobs.length.toString()} 
          icon={Briefcase} 
          color="bg-blue-50 text-primary"
        />
        <StatCard 
          title="Pending Proposals" 
          value={activeProposals.length.toString()} 
          icon={Clock} 
          color="bg-amber-50 text-amber-600"
        />
        <StatCard 
          title="Leads" 
          value={leads.length.toString()} 
          icon={User} 
          color="bg-purple-50 text-purple-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity / Jobs */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold font-display">Active Projects</h3>
          </div>
          
          <div className="bg-card rounded-2xl shadow-sm border border-border overflow-hidden">
            {activeJobs.length > 0 ? (
              <div className="divide-y divide-border/50">
                {activeJobs.map((job) => (
                  <div key={job.id} className="p-6 flex items-center justify-between hover:bg-muted/30 transition-colors">
                    <div className="space-y-1">
                      <h4 className="font-semibold text-foreground">{job.title}</h4>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>{job.client}</span>
                        <span>•</span>
                        <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full text-xs font-medium">Active</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-foreground">${job.rate}</p>
                      <p className="text-xs text-muted-foreground">Fixed Price</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center text-muted-foreground">
                <Briefcase className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>No active jobs yet. Time to find some work!</p>
              </div>
            )}
          </div>
        </div>

        {/* Profile Completeness */}
        <div className="space-y-6">
          <h3 className="text-xl font-bold font-display">Profile Status</h3>
          <Card className="border-border shadow-sm">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="relative">
                  {/* Placeholder Avatar */}
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-xl shadow-lg">
                    {user?.fullName ? user.fullName.charAt(0) : "U"}
                  </div>
                  <div className="absolute -bottom-1 -right-1 bg-green-500 border-2 border-white rounded-full p-1">
                    <CheckCircle className="w-3 h-3 text-white" />
                  </div>
                </div>
                <div>
                  <h4 className="font-bold">{user?.fullName || "Update Profile"}</h4>
                  <p className="text-sm text-muted-foreground">{user?.title || "No Title Set"}</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Profile Completeness</span>
                  <span className="font-bold text-primary">85%</span>
                </div>
                <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-primary w-[85%] rounded-full" />
                </div>
                
                <div className="pt-4 border-t border-border mt-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide">Hourly Rate</p>
                      <p className="font-bold text-lg">${user?.hourlyRate || "0"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide">Niche</p>
                      <p className="font-bold text-lg truncate max-w-[120px] mx-auto">{user?.niche || "-"}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, trend, trendUp, color }: any) {
  return (
    <Card className="border-border shadow-sm hover:shadow-md transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
            <h3 className="text-2xl font-bold font-display">{value}</h3>
          </div>
          <div className={`p-3 rounded-xl ${color}`}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
        {trend && (
          <div className="mt-4 flex items-center text-sm">
            <span className={`flex items-center font-medium ${trendUp ? 'text-green-600' : 'text-red-600'}`}>
              {trendUp ? <ArrowUpRight className="w-4 h-4 mr-1" /> : null}
              {trend}
            </span>
            <span className="text-muted-foreground ml-2">from last month</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <Skeleton className="h-10 w-1/3" />
        <Skeleton className="h-4 w-1/4" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
      </div>
      <div className="grid grid-cols-3 gap-8">
        <Skeleton className="col-span-2 h-96 rounded-xl" />
        <Skeleton className="h-96 rounded-xl" />
      </div>
    </div>
  );
}
