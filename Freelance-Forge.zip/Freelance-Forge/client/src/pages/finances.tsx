import { useState } from "react";
import { useFinances, useCreateFinance } from "@/hooks/use-finances";
import { DEMO_USER_ID } from "@/hooks/use-user";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertFinanceSchema } from "@shared/schema";
import { z } from "zod";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";
import { 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  DollarSign,
  Wallet
} from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Finances() {
  const { data: finances, isLoading } = useFinances();
  const [open, setOpen] = useState(false);

  const earnings = finances?.filter(f => f.type === "earning") || [];
  const expenses = finances?.filter(f => f.type === "expense") || [];
  
  const totalEarned = earnings.reduce((acc, curr) => acc + Number(curr.amount), 0);
  const totalSpent = expenses.reduce((acc, curr) => acc + Number(curr.amount), 0);
  const netIncome = totalEarned - totalSpent;

  // Prepare chart data (monthly)
  const chartData = earnings.reduce((acc: any[], curr) => {
    const date = new Date(curr.date || new Date());
    const month = format(date, "MMM");
    const existing = acc.find(item => item.name === month);
    if (existing) {
      existing.amount += Number(curr.amount);
    } else {
      acc.push({ name: month, amount: Number(curr.amount) });
    }
    return acc;
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-display font-bold">Financial Overview</h2>
          <p className="text-muted-foreground">Track your income and manage expenses.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="shadow-lg shadow-primary/25">
              <Plus className="w-4 h-4 mr-2" /> Add Transaction
            </Button>
          </DialogTrigger>
          <TransactionDialog close={() => setOpen(false)} />
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-emerald-200/50 rounded-lg">
                <TrendingUp className="w-6 h-6 text-emerald-700" />
              </div>
              <span className="text-sm font-medium text-emerald-800 bg-emerald-200/50 px-2 py-1 rounded">Income</span>
            </div>
            <h3 className="text-3xl font-bold text-emerald-900">${totalEarned.toLocaleString()}</h3>
            <p className="text-emerald-700 text-sm mt-1">Total Earnings</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-red-200/50 rounded-lg">
                <TrendingDown className="w-6 h-6 text-red-700" />
              </div>
              <span className="text-sm font-medium text-red-800 bg-red-200/50 px-2 py-1 rounded">Expenses</span>
            </div>
            <h3 className="text-3xl font-bold text-red-900">${totalSpent.toLocaleString()}</h3>
            <p className="text-red-700 text-sm mt-1">Total Expenses</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-blue-200/50 rounded-lg">
                <Wallet className="w-6 h-6 text-blue-700" />
              </div>
              <span className="text-sm font-medium text-blue-800 bg-blue-200/50 px-2 py-1 rounded">Net</span>
            </div>
            <h3 className="text-3xl font-bold text-blue-900">${netIncome.toLocaleString()}</h3>
            <p className="text-blue-700 text-sm mt-1">Net Income</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Chart */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Income Trend</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderRadius: '8px', border: '1px solid hsl(var(--border))' }}
                  />
                  <Area type="monotone" dataKey="amount" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorIncome)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                No data to display
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            {finances && finances.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Description</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {finances.slice(0, 5).map((finance) => (
                    <TableRow key={finance.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${finance.type === 'earning' ? 'bg-emerald-500' : 'bg-red-500'}`} />
                          {finance.description}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-xs">
                        {finance.date && format(new Date(finance.date), "MMM d")}
                      </TableCell>
                      <TableCell className={`text-right font-bold ${finance.type === 'earning' ? 'text-emerald-600' : 'text-red-600'}`}>
                        {finance.type === 'earning' ? '+' : '-'}${Number(finance.amount).toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No transactions yet.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function TransactionDialog({ close }: { close: () => void }) {
  const createMutation = useCreateFinance();
  const form = useForm({
    resolver: zodResolver(insertFinanceSchema.omit({ userId: true })),
    defaultValues: {
      description: "",
      amount: "",
      type: "earning",
    }
  });

  const onSubmit = (data: any) => {
    createMutation.mutate({ ...data, userId: DEMO_USER_ID }, {
      onSuccess: () => {
        close();
        form.reset();
      }
    });
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Add Transaction</DialogTitle>
      </DialogHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <FormField control={form.control} name="type" render={({ field }) => (
              <FormItem>
                <FormLabel>Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="earning">Earning</SelectItem>
                    <SelectItem value="expense">Expense</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="amount" render={({ field }) => (
              <FormItem>
                <FormLabel>Amount ($)</FormLabel>
                <FormControl><Input {...field} type="number" step="0.01" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
          </div>
          
          <FormField control={form.control} name="description" render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl><Input {...field} placeholder="e.g. Logo Design Project" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />

          <Button type="submit" className="w-full" disabled={createMutation.isPending}>
            {createMutation.isPending ? "Adding..." : "Add Transaction"}
          </Button>
        </form>
      </Form>
    </DialogContent>
  );
}
