import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Target, 
  Search, 
  FileText, 
  MessageCircle, 
  TrendingUp,
  Award,
  Zap
} from "lucide-react";

export default function Guide() {
  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div className="text-center space-y-4 py-8">
        <h1 className="text-4xl md:text-5xl font-display font-bold gradient-text">
          The Freelancer's Playbook
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          A step-by-step guide to building a successful freelance business from scratch.
        </p>
      </div>

      {/* Phase 1 */}
      <section className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">1</div>
          <h2 className="text-2xl font-bold font-display">Set Up Your Foundation</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <GuideCard 
            icon={Target}
            title="Niche Down"
            description="Don't be a generalist. Choose a specific skill (e.g., writing, coding) and define the exact problem you solve for clients."
          />
          <GuideCard 
            icon={Award}
            title="Build Your Profile"
            description="Your profile is your sales page. Add a professional headshot, detailed experience, and a portfolio with case studies."
          />
        </div>
      </section>

      {/* Phase 2 */}
      <section className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-accent text-accent-foreground flex items-center justify-center font-bold text-lg">2</div>
          <h2 className="text-2xl font-bold font-display">Find & Win Jobs</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <GuideCard 
            icon={Search}
            title="Search Smart"
            description="Use specific keywords to find relevant hourly or fixed-price projects."
          />
          <GuideCard 
            icon={FileText}
            title="Craft Proposals"
            description="Tailor every proposal. Explain your unique approach and how you'll solve their problem."
          />
          <GuideCard 
            icon={MessageCircle}
            title="Stand Out"
            description="Offer a free consultation or intro call to build rapport before they hire."
          />
        </div>
      </section>

      {/* Phase 3 */}
      <section className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-lg">3</div>
          <h2 className="text-2xl font-bold font-display">Manage & Grow</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <GuideCard 
            icon={Zap}
            title="Deliver Quality"
            description="Excellent work leads to 5-star reviews, which boosts your Job Success Score (JSS)."
          />
          <GuideCard 
            icon={TrendingUp}
            title="Track Finances"
            description="Keep an eye on your earnings and remember to save for taxes."
          />
        </div>
      </section>
    </div>
  );
}

function GuideCard({ icon: Icon, title, description }: any) {
  return (
    <Card className="hover:shadow-lg transition-all duration-300 border-border h-full">
      <CardHeader>
        <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center mb-2">
          <Icon className="w-6 h-6 text-foreground" />
        </div>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground leading-relaxed">{description}</p>
      </CardContent>
    </Card>
  );
}
