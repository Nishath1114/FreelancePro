import { useState } from "react";
import { useJobs, useCreateJob, useUpdateJob, useDeleteJob } from "@/hooks/use-jobs";
import { DEMO_USER_ID } from "@/hooks/use-user";
import { insertJobSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { 
  Plus, 
  Search, 
  MoreHorizontal, 
  DollarSign, 
  Calendar, 
  Briefcase 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

const COLUMNS = [
  { id: 'leads', title: 'Leads', color: 'bg-gray-100 text-gray-700' },
  { id: 'applied', title: 'Applied', color: 'bg-blue-100 text-blue-700' },
  { id: 'interviewing', title: 'Interviewing', color: 'bg-amber-100 text-amber-700' },
  { id: 'active', title: 'Active', color: 'bg-emerald-100 text-emerald-700' },
  { id: 'completed', title: 'Completed', color: 'bg-purple-100 text-purple-700' }
];

export default function Jobs() {
  const { data: jobs, isLoading } = useJobs();
  const updateMutation = useUpdateJob();
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const onDragEnd = (result: any) => {
    if (!result.destination) return;
    const jobId = parseInt(result.draggableId);
    const newStatus = result.destination.droppableId;
    
    // Optimistic UI update could go here
    updateMutation.mutate({ id: jobId, status: newStatus });
  };

  const filteredJobs = jobs?.filter(job => 
    job.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    job.client?.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-display font-bold">Job Pipeline</h2>
          <p className="text-muted-foreground">Track your applications and active projects.</p>
        </div>
        <div className="flex gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search jobs..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="shadow-lg shadow-primary/25">
                <Plus className="w-4 h-4 mr-2" /> Add Job
              </Button>
            </DialogTrigger>
            <AddJobDialog close={() => setOpen(false)} />
          </Dialog>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center flex-1">Loading pipeline...</div>
      ) : (
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="flex-1 overflow-x-auto pb-4">
            <div className="flex gap-6 h-full min-w-[1000px]">
              {COLUMNS.map(column => (
                <div key={column.id} className="flex-1 min-w-[280px] flex flex-col bg-muted/20 rounded-xl border border-border/50">
                  <div className="p-4 flex items-center justify-between border-b border-border/50 bg-card/50 rounded-t-xl">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-sm">{column.title}</h3>
                      <Badge variant="secondary" className="rounded-full px-2">
                        {filteredJobs.filter(j => j.status === column.id).length}
                      </Badge>
                    </div>
                  </div>
                  
                  <Droppable droppableId={column.id}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`p-3 flex-1 overflow-y-auto space-y-3 transition-colors ${
                          snapshot.isDraggingOver ? "bg-muted/30" : ""
                        }`}
                      >
                        {filteredJobs
                          .filter(job => job.status === column.id)
                          .map((job, index) => (
                            <Draggable key={job.id} draggableId={job.id.toString()} index={index}>
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  className={`select-none ${snapshot.isDragging ? 'rotate-2 scale-105 shadow-xl z-50' : ''}`}
                                  style={provided.draggableProps.style}
                                >
                                  <JobCard job={job} />
                                </div>
                              )}
                            </Draggable>
                          ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </div>
              ))}
            </div>
          </div>
        </DragDropContext>
      )}
    </div>
  );
}

function JobCard({ job }: { job: any }) {
  const deleteMutation = useDeleteJob();
  
  return (
    <Card className="hover:shadow-md transition-shadow border-border shadow-sm">
      <CardContent className="p-4 space-y-3">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <h4 className="font-semibold text-sm line-clamp-2 leading-tight">{job.title}</h4>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Briefcase className="w-3 h-3" /> {job.client || "Unknown Client"}
            </p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6 -mr-2">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => deleteMutation.mutate(job.id)}>
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-border/50">
          <Badge variant="outline" className="text-xs font-normal">
            {job.platform}
          </Badge>
          {job.rate && (
            <span className="text-xs font-semibold text-green-600 flex items-center">
              <DollarSign className="w-3 h-3 mr-0.5" />
              {job.rate}
            </span>
          )}
        </div>
        
        {job.createdAt && (
          <div className="text-[10px] text-muted-foreground flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            {format(new Date(job.createdAt), "MMM d, yyyy")}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function AddJobDialog({ close }: { close: () => void }) {
  const createMutation = useCreateJob();
  const form = useForm({
    resolver: zodResolver(insertJobSchema.omit({ userId: true, createdAt: true })),
    defaultValues: {
      title: "",
      client: "",
      platform: "Upwork",
      status: "leads",
      rate: "",
      proposalText: "",
    }
  });

  const onSubmit = (data: any) => {
    createMutation.mutate({ ...data, userId: DEMO_USER_ID }, {
      onSuccess: () => {
        close();
        form.reset();
      }
    });
  };

  return (
    <DialogContent className="sm:max-w-[500px]">
      <DialogHeader>
        <DialogTitle>Add New Job Lead</DialogTitle>
      </DialogHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField control={form.control} name="title" render={({ field }) => (
            <FormItem>
              <FormLabel>Job Title</FormLabel>
              <FormControl><Input {...field} placeholder="e.g. React Frontend Needed" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          
          <div className="grid grid-cols-2 gap-4">
            <FormField control={form.control} name="client" render={({ field }) => (
              <FormItem>
                <FormLabel>Client Name</FormLabel>
                <FormControl><Input {...field} placeholder="Optional" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="rate" render={({ field }) => (
              <FormItem>
                <FormLabel>Budget/Rate</FormLabel>
                <FormControl><Input {...field} type="number" placeholder="500" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <FormField control={form.control} name="platform" render={({ field }) => (
              <FormItem>
                <FormLabel>Platform</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select platform" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Upwork">Upwork</SelectItem>
                    <SelectItem value="Fiverr">Fiverr</SelectItem>
                    <SelectItem value="LinkedIn">LinkedIn</SelectItem>
                    <SelectItem value="Direct">Direct Client</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="status" render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {COLUMNS.map(col => (
                      <SelectItem key={col.id} value={col.id}>{col.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />
          </div>

          <FormField control={form.control} name="proposalText" render={({ field }) => (
            <FormItem>
              <FormLabel>Draft Proposal / Notes</FormLabel>
              <FormControl><Textarea {...field} placeholder="Jot down ideas for your proposal..." /></FormControl>
              <FormMessage />
            </FormItem>
          )} />

          <Button type="submit" className="w-full" disabled={createMutation.isPending}>
            {createMutation.isPending ? "Creating..." : "Create Job"}
          </Button>
        </form>
      </Form>
    </DialogContent>
  );
}
