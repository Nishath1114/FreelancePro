import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useUser, useUpdateUser } from "@/hooks/use-user";
import { usePortfolio, useCreatePortfolioItem, useDeletePortfolioItem } from "@/hooks/use-portfolio";
import { useCertifications, useCreateCertification, useDeleteCertification } from "@/hooks/use-certifications";
import { DEMO_USER_ID } from "@/hooks/use-user";
import { insertUserSchema, insertPortfolioItemSchema, insertCertificationSchema } from "@shared/schema";
import { 
  Loader2, 
  Plus, 
  Trash2, 
  Upload, 
  Video, 
  Image as ImageIcon,
  ExternalLink,
  Award,
  PenTool
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

// === Profile Form ===
const profileSchema = insertUserSchema.pick({
  fullName: true,
  title: true,
  bio: true,
  niche: true,
  hourlyRate: true,
});

function ProfileForm({ user }: { user: any }) {
  const { toast } = useToast();
  const updateMutation = useUpdateUser();
  
  const form = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      title: user?.title || "",
      bio: user?.bio || "",
      niche: user?.niche || "",
      hourlyRate: user?.hourlyRate || "",
    }
  });

  const onSubmit = (data: any) => {
    updateMutation.mutate({ id: user.id, ...data }, {
      onSuccess: () => {
        toast({ title: "Profile updated", description: "Your changes have been saved." });
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to update profile.", variant: "destructive" });
      }
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField control={form.control} name="fullName" render={({ field }) => (
            <FormItem>
              <FormLabel>Full Name</FormLabel>
              <FormControl><Input {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="title" render={({ field }) => (
            <FormItem>
              <FormLabel>Professional Title</FormLabel>
              <FormControl><Input {...field} placeholder="e.g. Senior Product Designer" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
        </div>
        
        <FormField control={form.control} name="bio" render={({ field }) => (
          <FormItem>
            <FormLabel>Bio / About Me</FormLabel>
            <FormControl><Textarea {...field} className="min-h-[100px]" placeholder="Tell clients about your expertise..." /></FormControl>
            <FormMessage />
          </FormItem>
        )} />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField control={form.control} name="niche" render={({ field }) => (
            <FormItem>
              <FormLabel>Niche</FormLabel>
              <FormControl><Input {...field} placeholder="e.g. SaaS Case Studies" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="hourlyRate" render={({ field }) => (
            <FormItem>
              <FormLabel>Hourly Rate ($)</FormLabel>
              <FormControl><Input type="number" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
        </div>

        <Button type="submit" disabled={updateMutation.isPending} className="w-full md:w-auto">
          {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Save Profile
        </Button>
      </form>
    </Form>
  );
}

// === Portfolio Section ===
function PortfolioSection({ userId }: { userId: number }) {
  const { data: items, isLoading } = usePortfolio(userId);
  const deleteMutation = useDeletePortfolioItem();
  const [open, setOpen] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold font-display">Portfolio & Case Studies</h3>
          <p className="text-sm text-muted-foreground">Showcase your best work to win clients.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="w-4 h-4" /> Add Project</Button>
          </DialogTrigger>
          <PortfolioDialogContent userId={userId} close={() => setOpen(false)} />
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-64 bg-muted/20 animate-pulse rounded-xl" />
          <div className="h-64 bg-muted/20 animate-pulse rounded-xl" />
        </div>
      ) : items && items.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {items.map((item) => (
            <Card key={item.id} className="group overflow-hidden border-border hover:shadow-lg transition-all duration-300">
              <div className="aspect-video bg-secondary relative overflow-hidden">
                {/* Simulated Image */}
                <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
                  <ImageIcon className="w-12 h-12 text-muted-foreground/30" />
                </div>
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                  <Button variant="secondary" size="sm" onClick={() => window.open(item.projectUrl || '#', '_blank')}>
                    View Project
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => deleteMutation.mutate(item.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <CardContent className="p-5">
                <h4 className="font-bold text-lg mb-2">{item.title}</h4>
                <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
                <div className="mt-4 pt-4 border-t border-border flex items-center gap-2 text-xs font-medium text-primary">
                  <PenTool className="w-3 h-3" />
                  CASE STUDY AVAILABLE
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 border-2 border-dashed border-border rounded-xl">
          <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="w-6 h-6 text-primary" />
          </div>
          <h4 className="font-medium">No projects yet</h4>
          <p className="text-muted-foreground text-sm mt-1">Add your first case study to impress clients.</p>
        </div>
      )}
    </div>
  );
}

function PortfolioDialogContent({ userId, close }: { userId: number, close: () => void }) {
  const createMutation = useCreatePortfolioItem();
  const form = useForm({
    resolver: zodResolver(insertPortfolioItemSchema.omit({ userId: true })),
    defaultValues: {
      title: "",
      description: "",
      projectUrl: "",
      caseStudy: "",
    }
  });

  const onSubmit = (data: any) => {
    createMutation.mutate({ ...data, userId }, {
      onSuccess: () => {
        close();
        form.reset();
      }
    });
  };

  return (
    <DialogContent className="sm:max-w-[500px]">
      <DialogHeader>
        <DialogTitle>Add Portfolio Item</DialogTitle>
      </DialogHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField control={form.control} name="title" render={({ field }) => (
            <FormItem>
              <FormLabel>Project Title</FormLabel>
              <FormControl><Input {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="description" render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl><Textarea {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="projectUrl" render={({ field }) => (
            <FormItem>
              <FormLabel>Project URL</FormLabel>
              <FormControl><Input {...field} placeholder="https://..." /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="caseStudy" render={({ field }) => (
            <FormItem>
              <FormLabel>Case Study Details</FormLabel>
              <FormControl><Textarea {...field} placeholder="What problem did you solve?" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <Button type="submit" className="w-full" disabled={createMutation.isPending}>
            {createMutation.isPending ? "Adding..." : "Add Project"}
          </Button>
        </form>
      </Form>
    </DialogContent>
  );
}

// === Certifications Section ===
function CertificationsSection({ userId }: { userId: number }) {
  const { data: certs } = useCertifications(userId);
  const deleteMutation = useDeleteCertification();
  const createMutation = useCreateCertification();
  const [name, setName] = useState("");
  const [issuer, setIssuer] = useState("");

  const handleAdd = () => {
    if (!name || !issuer) return;
    createMutation.mutate({ userId, name, issuer }, {
      onSuccess: () => {
        setName("");
        setIssuer("");
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Award className="w-5 h-5 text-primary" />
        <h3 className="text-xl font-bold font-display">Certifications</h3>
      </div>
      
      <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <Input 
            placeholder="Certification Name" 
            value={name} 
            onChange={e => setName(e.target.value)} 
          />
          <Input 
            placeholder="Issuing Organization" 
            value={issuer} 
            onChange={e => setIssuer(e.target.value)} 
          />
          <Button onClick={handleAdd} disabled={createMutation.isPending}>Add</Button>
        </div>

        <div className="space-y-3">
          {certs?.map((cert) => (
            <div key={cert.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
              <div>
                <p className="font-semibold">{cert.name}</p>
                <p className="text-xs text-muted-foreground">{cert.issuer}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate(cert.id)}>
                <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
              </Button>
            </div>
          ))}
          {(!certs || certs.length === 0) && (
            <p className="text-center text-sm text-muted-foreground py-4">No certifications added yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Profile() {
  const { data: user, isLoading } = useUser();

  if (isLoading) return <div className="flex items-center justify-center h-96"><Loader2 className="animate-spin w-8 h-8 text-primary" /></div>;

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div>
        <h2 className="text-3xl font-display font-bold">Profile Builder</h2>
        <p className="text-muted-foreground mt-1">Set up your foundation to attract high-quality clients.</p>
      </div>

      <Tabs defaultValue="details" className="w-full">
        <TabsList className="mb-8 w-full md:w-auto">
          <TabsTrigger value="details">Basic Details</TabsTrigger>
          <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
          <TabsTrigger value="media">Media & Certs</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
          <Card>
            <CardHeader>
              <CardTitle>Professional Information</CardTitle>
              <CardDescription>This is what clients will see on your profile.</CardDescription>
            </CardHeader>
            <CardContent>
              <ProfileForm user={user} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="portfolio" className="animate-in slide-in-from-bottom-4 duration-500">
          <PortfolioSection userId={user?.id || DEMO_USER_ID} />
        </TabsContent>

        <TabsContent value="media" className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Video Introduction</CardTitle>
                <CardDescription>A short video pitch helps build trust.</CardDescription>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Video className="w-8 h-8 text-primary" />
                </div>
                <Button variant="outline" className="w-full">
                  <Upload className="mr-2 w-4 h-4" /> Upload Video
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Profile Headshot</CardTitle>
                <CardDescription>Professional photo increases response rates.</CardDescription>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <UserCircle className="w-8 h-8 text-primary" />
                </div>
                <Button variant="outline" className="w-full">
                  <Upload className="mr-2 w-4 h-4" /> Upload Photo
                </Button>
              </CardContent>
            </Card>
          </div>

          <CertificationsSection userId={user?.id || DEMO_USER_ID} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

import { UserCircle } from "lucide-react";
