
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // User Routes
  app.get(api.user.get.path, async (req, res) => {
    const user = await storage.getUser(Number(req.params.id));
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  });

  app.patch(api.user.update.path, async (req, res) => {
    try {
      const input = api.user.update.input.parse(req.body);
      const user = await storage.updateUser(Number(req.params.id), input);
      res.json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Portfolio Routes
  app.get(api.portfolio.list.path, async (req, res) => {
    const userId = Number(req.query.userId);
    if (!userId) return res.status(400).json({ message: "UserId required" });
    const items = await storage.getPortfolioItems(userId);
    res.json(items);
  });

  app.post(api.portfolio.create.path, async (req, res) => {
    try {
      const input = api.portfolio.create.input.parse(req.body);
      const item = await storage.createPortfolioItem(input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.message });
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.delete(api.portfolio.delete.path, async (req, res) => {
    await storage.deletePortfolioItem(Number(req.params.id));
    res.status(204).end();
  });

  // Job Routes
  app.get(api.jobs.list.path, async (req, res) => {
    const userId = Number(req.query.userId);
    if (!userId) return res.status(400).json({ message: "UserId required" });
    const items = await storage.getJobs(userId);
    res.json(items);
  });

  app.post(api.jobs.create.path, async (req, res) => {
    try {
      const input = api.jobs.create.input.parse(req.body);
      const item = await storage.createJob(input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.message });
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.patch(api.jobs.update.path, async (req, res) => {
    try {
      const input = api.jobs.update.input.parse(req.body);
      const item = await storage.updateJob(Number(req.params.id), input);
      res.json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.message });
      res.status(404).json({ message: "Job not found" });
    }
  });

  app.delete(api.jobs.delete.path, async (req, res) => {
    await storage.deleteJob(Number(req.params.id));
    res.status(204).end();
  });

  // Finance Routes
  app.get(api.finances.list.path, async (req, res) => {
    const userId = Number(req.query.userId);
    if (!userId) return res.status(400).json({ message: "UserId required" });
    const items = await storage.getFinances(userId);
    res.json(items);
  });

  app.post(api.finances.create.path, async (req, res) => {
    try {
      const input = api.finances.create.input.parse(req.body);
      const item = await storage.createFinance(input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.message });
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // Certifications Routes
  app.get(api.certifications.list.path, async (req, res) => {
    const userId = Number(req.query.userId);
    if (!userId) return res.status(400).json({ message: "UserId required" });
    const items = await storage.getCertifications(userId);
    res.json(items);
  });

  app.post(api.certifications.create.path, async (req, res) => {
    try {
      const input = api.certifications.create.input.parse(req.body);
      const item = await storage.createCertification(input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.message });
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.delete(api.certifications.delete.path, async (req, res) => {
    await storage.deleteCertification(Number(req.params.id));
    res.status(204).end();
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingUser = await storage.getUserByUsername("freelancer");
  if (!existingUser) {
    const user = await storage.createUser({
      username: "freelancer",
      password: "password",
      fullName: "Alex Rivera",
      title: "Full Stack Developer",
      bio: "Helping SaaS companies build scalable web applications.",
      niche: "SaaS Development",
      hourlyRate: "85",
      headshotUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
    });

    await storage.createPortfolioItem({
      userId: user.id,
      title: "E-commerce Redesign",
      description: "Complete overhaul of a Shopify store focusing on conversion rate optimization.",
      caseStudy: "The client needed a fresh look to attract younger demographics. We implemented a mobile-first design...",
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80",
      projectUrl: "https://example.com"
    });

    await storage.createJob({
      userId: user.id,
      title: "React Dashboard Project",
      client: "TechCorp Inc",
      platform: "Upwork",
      status: "active",
      rate: "2500",
      proposalText: "I can help you build this dashboard using React and Recharts..."
    });

    await storage.createFinance({
      userId: user.id,
      amount: "2500",
      description: "Project Milestone 1",
      type: "earning",
      date: new Date()
    });

    await storage.createCertification({
      userId: user.id,
      name: "AWS Certified Developer",
      issuer: "Amazon Web Services",
      date: new Date()
    });
  }
}
