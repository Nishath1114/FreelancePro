
import { db } from "./db";
import { 
  users, portfolioItems, jobs, finances, certifications,
  type User, type InsertUser,
  type PortfolioItem, type InsertPortfolioItem,
  type Job, type InsertJob,
  type Finance, type InsertFinance,
  type Certification, type InsertCertification
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;

  // Portfolio
  getPortfolioItems(userId: number): Promise<PortfolioItem[]>;
  createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem>;
  deletePortfolioItem(id: number): Promise<void>;

  // Jobs
  getJobs(userId: number): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, job: Partial<InsertJob>): Promise<Job>;
  deleteJob(id: number): Promise<void>;

  // Finances
  getFinances(userId: number): Promise<Finance[]>;
  createFinance(finance: InsertFinance): Promise<Finance>;

  // Certifications
  getCertifications(userId: number): Promise<Certification[]>;
  createCertification(cert: InsertCertification): Promise<Certification>;
  deleteCertification(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  // Portfolio
  async getPortfolioItems(userId: number): Promise<PortfolioItem[]> {
    return await db.select().from(portfolioItems).where(eq(portfolioItems.userId, userId)).orderBy(desc(portfolioItems.createdAt));
  }

  async createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem> {
    const [newItem] = await db.insert(portfolioItems).values(item).returning();
    return newItem;
  }

  async deletePortfolioItem(id: number): Promise<void> {
    await db.delete(portfolioItems).where(eq(portfolioItems.id, id));
  }

  // Jobs
  async getJobs(userId: number): Promise<Job[]> {
    return await db.select().from(jobs).where(eq(jobs.userId, userId)).orderBy(desc(jobs.createdAt));
  }

  async createJob(item: InsertJob): Promise<Job> {
    const [newJob] = await db.insert(jobs).values(item).returning();
    return newJob;
  }

  async updateJob(id: number, updates: Partial<InsertJob>): Promise<Job> {
    const [updatedJob] = await db.update(jobs).set(updates).where(eq(jobs.id, id)).returning();
    return updatedJob;
  }

  async deleteJob(id: number): Promise<void> {
    await db.delete(jobs).where(eq(jobs.id, id));
  }

  // Finances
  async getFinances(userId: number): Promise<Finance[]> {
    return await db.select().from(finances).where(eq(finances.userId, userId)).orderBy(desc(finances.date));
  }

  async createFinance(item: InsertFinance): Promise<Finance> {
    const [newFinance] = await db.insert(finances).values(item).returning();
    return newFinance;
  }

  // Certifications
  async getCertifications(userId: number): Promise<Certification[]> {
    return await db.select().from(certifications).where(eq(certifications.userId, userId));
  }

  async createCertification(item: InsertCertification): Promise<Certification> {
    const [newCert] = await db.insert(certifications).values(item).returning();
    return newCert;
  }

  async deleteCertification(id: number): Promise<void> {
    await db.delete(certifications).where(eq(certifications.id, id));
  }
}

export const storage = new DatabaseStorage();
