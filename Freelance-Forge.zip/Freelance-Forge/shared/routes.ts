
import { z } from 'zod';
import { 
  insertUserSchema, 
  insertPortfolioItemSchema, 
  insertJobSchema, 
  insertFinanceSchema, 
  insertCertificationSchema,
  users,
  portfolioItems,
  jobs,
  finances,
  certifications
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  // User/Profile Routes
  user: {
    get: {
      method: 'GET' as const,
      path: '/api/user/:id',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/user/:id',
      input: insertUserSchema.partial(),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  // Portfolio Routes
  portfolio: {
    list: {
      method: 'GET' as const,
      path: '/api/portfolio',
      input: z.object({ userId: z.coerce.number() }),
      responses: {
        200: z.array(z.custom<typeof portfolioItems.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/portfolio',
      input: insertPortfolioItemSchema,
      responses: {
        201: z.custom<typeof portfolioItems.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/portfolio/:id',
      responses: {
        204: z.void(),
      },
    }
  },
  // Job/Proposal Routes
  jobs: {
    list: {
      method: 'GET' as const,
      path: '/api/jobs',
      input: z.object({ userId: z.coerce.number() }),
      responses: {
        200: z.array(z.custom<typeof jobs.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/jobs',
      input: insertJobSchema,
      responses: {
        201: z.custom<typeof jobs.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/jobs/:id',
      input: insertJobSchema.partial(),
      responses: {
        200: z.custom<typeof jobs.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/jobs/:id',
      responses: {
        204: z.void(),
      },
    }
  },
  // Finance Routes
  finances: {
    list: {
      method: 'GET' as const,
      path: '/api/finances',
      input: z.object({ userId: z.coerce.number() }),
      responses: {
        200: z.array(z.custom<typeof finances.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/finances',
      input: insertFinanceSchema,
      responses: {
        201: z.custom<typeof finances.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  // Certifications
  certifications: {
    list: {
      method: 'GET' as const,
      path: '/api/certifications',
      input: z.object({ userId: z.coerce.number() }),
      responses: {
        200: z.array(z.custom<typeof certifications.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/certifications',
      input: insertCertificationSchema,
      responses: {
        201: z.custom<typeof certifications.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/certifications/:id',
      responses: {
        204: z.void(),
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
